import * as handler from './index.mjs'

handler.handler()
