import { getExchangeRate } from './bcvScraping.mjs';
import AWS from 'aws-sdk';

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const tableName = process.env.TABLE_NAME;;

export const handler = async () => {
  try {
    // Obtener tasa de cambio
    const exchange = await getExchangeRate();
    if (!exchange) throw new Error('Error con la página del BCV');

    // Actualizar tasa actual
    await dynamoDb.put({
      TableName: tableName,
      Item: {
        PK: 'current',
        SK: 'rates',
        ...exchange,
        lastUpdated: new Date().toISOString()
      }
    }).promise();

    // Registrar auditoría
    const auditDate = new Date().toISOString().split('T')[0];
    await dynamoDb.put({
      TableName: tableName,
      Item: {
        PK: `audit#${auditDate}`,
        SK: 'rates',
        ...exchange,
        timestamp: new Date().toISOString()
      }
    }).promise();

    return { statusCode: 200 };
  } catch (error) {
    console.error(error);
    return { statusCode: 200, body: JSON.stringify({ error }) };
  }
};