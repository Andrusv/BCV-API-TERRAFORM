import fetch from 'node-fetch'; // Importa el módulo node-fetch
import cheerio from 'cheerio';
import https from 'https'; // Importa el módulo https

// Crea un nuevo agente con verificación de certificado deshabilitada
const agent = new https.Agent({
  rejectUnauthorized: false,
});

export async function getExchangeRate() {
  try {
    const response = await fetch('https://www.bcv.org.ve', { agent });
    const data = await response.text();

    const $ = cheerio.load(data);

    const exchangeRateUSDText = $('#dolar div div div strong').text();
    const exchangeRateUSD = parseFloat(exchangeRateUSDText.replace(',', '.')).toFixed(2);

    const exchangeRateEURText = $('#euro div div div strong').text();
    const exchangeRateEUR = parseFloat(exchangeRateEURText.replace(',', '.')).toFixed(2);

    const exchangeRateCNYText = $('#yuan div div div strong').text();
    const exchangeRateCNY = parseFloat(exchangeRateCNYText.replace(',', '.')).toFixed(2);

    const exchangeRateTRYText = $('#lira div div div strong').text();
    const exchangeRateTRY = parseFloat(exchangeRateTRYText.replace(',', '.')).toFixed(2);

    const exchangeRateRUBText = $('#rublo div div div strong').text();
    const exchangeRateRUB = parseFloat(exchangeRateRUBText.replace(',', '.')).toFixed(2);

    console.log('Tipo de cambio (EUR):' + exchangeRateEUR + '\nTipo de cambio (CNY):' + exchangeRateCNY + '\nTipo de cambio (TRY):' + exchangeRateTRY + '\nTipo de cambio (RUB):' + exchangeRateRUB + '\nTipo de cambio (USD):' + exchangeRateUSD);

    return { EUR: exchangeRateEUR, CNY: exchangeRateCNY, TRY: exchangeRateTRY, RUB: exchangeRateRUB, USD: exchangeRateUSD };
  } catch (error) {
    console.error('Error al obtener el tipo de cambio:', error.message);
    return null;
  }
}
