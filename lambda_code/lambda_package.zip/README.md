# BCV Currency AWS Lambda

Este proyecto obtiene los tipos de cambio del Banco Central de Venezuela y los expone mediante una función AWS Lambda.

---

## 🚀 Instalación y despliegue en AWS Lambda

### 1. Instala las dependencias

Abre una terminal en la carpeta del proyecto y ejecuta:

```sh
npm install
```

---

### 2. Genera el archivo ZIP con 7-Zip

Asegúrate de tener [7-Zip](https://www.7-zip.org/) instalado y estar en la carpeta raíz del proyecto.

Ejecuta este comando en PowerShell o CMD:

```sh
7z a -r bcv-currency.zip *
```

Esto creará el archivo `bcv-currency.zip` con todos los archivos y dependencias necesarias.

---

### 3. Sube el ZIP a AWS Lambda

1. Ve a [AWS Lambda Console](https://console.aws.amazon.com/lambda/).
2. Haz clic en **Create function**.
3. Elige **Author from scratch** y ponle un nombre.
4. Selecciona el entorno de ejecución (Node.js 18.x o superior).
5. En la sección **Code source**, selecciona **Upload from → .zip file** y sube el archivo `bcv-currency.zip`.

---

### 4. Configura el timeout

1. Ve a **Configuration → General configuration**.
2. Haz clic en **Edit**.
3. Cambia el **Timeout** a 10 segundos (o más si lo necesitas).
4. Guarda los cambios.

---

### 5. Prueba la función

1. Haz clic en **Test**.
2. Crea un evento de prueba (puedes dejar el JSON vacío).
3. Ejecuta la función y revisa el resultado.

---

## 📁 Estructura del proyecto

```
BcvCurrency/
├── index.mjs
├── bcvScraping.mjs
├── server.mjs
├── package.json
├── node_modules/
└── bcv-currency.zip
```

---

## 🛠️ Notas útiles

- Si usas ES Modules (`.mjs`), asegúrate de que Lambda esté configurado para Node.js 18.x o superior.
- Si tienes problemas de red, revisa las políticas de seguridad de AWS Lambda.
- Puedes modificar el código para agregar logs o manejar errores según tus necesidades.

---